/* JPT Partner Dynamic Outlet Access Bridge V1
   Additive only: reads partner_my_outlets() and rebuilds the existing outlet selector.
*/
(function () {
  'use strict';
  async function syncPartnerOutlets() {
    try {
      const client = window.sb;
      const select = document.getElementById('outletSelect');
      if (!client || !select) return;
      const { data, error } = await client.rpc('partner_my_outlets');
      if (error) { console.warn('[JPT Partner Access]', error.message); return; }
      const rows = Array.isArray(data) ? data : [];
      if (!rows.length) return;
      const current = select.value;
      select.innerHTML = '';
      rows.forEach(row => {
        const opt = document.createElement('option');
        opt.value = row.outlet_id;
        opt.textContent = `${row.outlet_name || row.outlet_id} (${row.outlet_id})${row.access_level === 'view' ? ' — VIEW' : ''}`;
        select.appendChild(opt);
      });
      const saved = localStorage.getItem('jpt_current_outlet');
      const preferred = rows.some(r => r.outlet_id === saved) ? saved : null;
      const keep = rows.some(r => r.outlet_id === current) ? current : null;
      select.value = preferred || keep || rows[0].outlet_id;
      select.dispatchEvent(new Event('change', { bubbles: true }));
      window.JPT_PARTNER_OUTLETS = rows;
      window.JPT_PARTNER_ACCESS_READY = true;
    } catch (e) { console.warn('[JPT Partner Access] bridge failed safely:', e); }
  }
  function boot() { if (window.sb) syncPartnerOutlets(); else setTimeout(boot, 400); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once:true }); else boot();
  window.JPT_syncPartnerOutlets = syncPartnerOutlets;
})();
