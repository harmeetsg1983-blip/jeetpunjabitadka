/* JPT Delivery Partner — Persistent Onboarding Fix V1
   Load this file in delivery-partner-v11.html immediately before </body>.
*/
(function () {
  const DEVICE_KEY = 'jpt_delivery_partner_device_v1';

  function makeDeviceKey() {
    let k = localStorage.getItem(DEVICE_KEY);
    if (!k) {
      const a = new Uint8Array(32);
      crypto.getRandomValues(a);
      k = Array.from(a, b => b.toString(16).padStart(2, '0')).join('');
      localStorage.setItem(DEVICE_KEY, k);
    }
    return k;
  }

  async function session() {
    const r = await sb.auth.getSession();
    if (r.data && r.data.session) return r.data.session;
    const x = await sb.auth.signInAnonymously();
    if (x.error) throw x.error;
    return x.data.session;
  }

  async function syncIdentity() {
    const s = await session();
    const key = makeDeviceKey();

    let q = await sb
      .from('delivery_partners')
      .select('id,status,is_active,onboarding_completed,verification_status')
      .eq('user_id', s.user.id)
      .maybeSingle();

    if (q.error) throw q.error;

    if (q.data) {
      /* This also binds an already-completed onboarding to this device.
         No second onboarding is required. */
      if (q.data.onboarding_completed) {
        const b = await sb.rpc('delivery_partner_bind_device', {
          p_device_key: key
        });
        if (b.error) throw b.error;
      }
    } else {
      /* New browser session: recover the previously onboarded rider
         by the private device identity stored in localStorage. */
      const r = await sb.rpc('delivery_partner_restore_device', {
        p_device_key: key
      });
      if (r.error) throw r.error;

      if (r.data && r.data.restored) {
        q = await sb
          .from('delivery_partners')
          .select('id,status,is_active,onboarding_completed,verification_status')
          .eq('user_id', s.user.id)
          .maybeSingle();
        if (q.error) throw q.error;
      }
    }

    return q.data || null;
  }

  function apply(data) {
    if (!data) return;

    const done = !!data.onboarding_completed;
    const verified = data.verification_status === 'verified';

    const state = document.getElementById('onboardState');
    const verify = document.getElementById('verifyState');
    const gate = document.getElementById('gate');
    const btn = document.getElementById('onboardBtn');
    const nav = document.getElementById('onboardNav');
    const gateText = document.getElementById('gateText');

    if (state) state.textContent = 'Onboarding: ' + (done ? 'Submitted' : 'Not submitted');
    if (verify) verify.textContent = 'Admin: ' + (data.verification_status || 'pending');

    if (typeof renderStatus === 'function') {
      renderStatus(data.status === 'online');
    }

    if (done) {
      window.__onboardingDone = true;

      /* Never ask a completed rider to onboard again. */
      if (btn) btn.classList.add('hidden');
      if (nav) nav.classList.add('hidden');

      if (verified) {
        if (gate) gate.classList.add('hidden');
      } else {
        if (gate) gate.classList.remove('hidden');
        if (gateText) {
          gateText.textContent =
            'Onboarding is complete. Waiting for admin approval before going ONLINE.';
        }
      }

      /* Keep the rider on Home after restoration. */
      if (typeof show === 'function') show('home');
    }
  }

  async function bootPersistenceFix() {
    try {
      const data = await syncIdentity();
      apply(data);
    } catch (e) {
      console.warn('JPT onboarding persistence:', e);
    }
  }

  window.addEventListener('load', bootPersistenceFix);
})();
