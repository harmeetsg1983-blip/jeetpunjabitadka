/* JPT Delivery Partner — Admin Approval Bridge V1
   Add this script to admin.html immediately before </body>.
   Additive only: does not replace existing admin UI or order logic.
*/
(function(){
  const TAB_ID='delivery-riders';
  const TAB_LABEL='🛵 Riders';
  const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function waitForAdmin(){
    if(!window.sb || !document.querySelector('#app')) return setTimeout(waitForAdmin,500);
    install();
  }
  function install(){
    if(document.getElementById('jptDeliveryRidersTab')) return;
    const tabs=document.querySelector('.tabs');
    const app=document.querySelector('#app');
    if(!tabs||!app) return setTimeout(install,500);

    const btn=document.createElement('button');
    btn.id='jptDeliveryRidersTab';
    btn.className='btn dark tab';
    btn.dataset.tab=TAB_ID;
    btn.textContent=TAB_LABEL;
    tabs.appendChild(btn);

    const pane=document.createElement('div');
    pane.id=TAB_ID;
    pane.className='tabpane card hidden';
    pane.innerHTML=`
      <div class="row"><h2>🛵 Delivery Partner Approvals</h2>
        <button class="btn dark" id="jptRiderRefresh">↻ Refresh</button>
      </div>
      <div class="muted">Review submitted riders. Approving a rider verifies them, activates the account and links them to active outlets. Reject only when the submitted information is not acceptable.</div>
      <div id="jptRiderMsg" class="msg"></div>
      <div id="jptRiderList"></div>`;
    app.insertBefore(pane, app.querySelector('.card:last-child'));

    btn.addEventListener('click',loadQueue);
    document.getElementById('jptRiderRefresh').addEventListener('click',loadQueue);
    loadQueue();
  }

  async function loadQueue(){
    const pane=document.getElementById(TAB_ID), list=document.getElementById('jptRiderList'), msg=document.getElementById('jptRiderMsg');
    if(!list||!window.sb) return;
    msg.textContent='Loading rider applications…';
    const r=await sb.rpc('delivery_partner_admin_queue');
    if(r.error){msg.textContent='Rider approvals: '+r.error.message; return;}
    const rows=Array.isArray(r.data)?r.data:[];
    msg.textContent=rows.length ? rows.length+' rider application(s) awaiting review.' : 'No rider applications awaiting review.';
    list.innerHTML=rows.length?rows.map(x=>`
      <div class="offer">
        <div class="row"><strong>${esc(x.full_name||'Unnamed rider')}</strong><span class="badge">${esc(x.admin_status||'pending')}</span></div>
        <div class="small">Phone: ${esc(x.phone||'—')}</div>
        <div class="small">Address: ${esc(x.address||'—')}</div>
        <div class="small">Submitted: ${x.submitted_at?new Date(x.submitted_at).toLocaleString():'—'}</div>
        <div class="switch" style="margin-top:10px">
          <button class="btn primary" data-rider-approve="${esc(x.id)}">✓ APPROVE</button>
          <button class="btn danger" data-rider-reject="${esc(x.id)}">✕ REJECT</button>
        </div>
      </div>`).join(''):'';

    list.querySelectorAll('[data-rider-approve]').forEach(b=>b.onclick=()=>review(b.dataset.riderApprove,'approve'));
    list.querySelectorAll('[data-rider-reject]').forEach(b=>b.onclick=()=>review(b.dataset.riderReject,'reject'));
  }

  async function review(id,decision){
    let reason=null;
    if(decision==='reject'){
      reason=prompt('Reason for rejection (optional):')||'Rejected during admin review';
    }
    if(decision==='approve' && !confirm('Approve this delivery partner? They will become VERIFIED, ACTIVE and eligible to go ONLINE.')) return;
    const msg=document.getElementById('jptRiderMsg');
    msg.textContent=decision==='approve'?'Approving rider…':'Rejecting rider…';
    const r=await sb.rpc('delivery_partner_admin_review',{
      p_delivery_partner_id:id,p_decision:decision,p_reason:reason
    });
    if(r.error){msg.textContent='Approval action failed: '+r.error.message;return;}
    msg.textContent=decision==='approve'
      ?'✓ Rider approved. They can now reopen the app and go ONLINE.'
      :'Rider rejected.';
    await loadQueue();
  }
  window.addEventListener('load',waitForAdmin);
})();
